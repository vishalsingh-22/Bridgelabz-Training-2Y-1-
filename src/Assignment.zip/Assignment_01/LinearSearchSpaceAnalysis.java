package Arrays.Assignment_01;

public class LinearSearchSpaceAnalysis {
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] arr = {8, 61, 2, 3, 4, 0};
        int target = 4;
        int result = linearSearch(arr, target);
        System.out.println("Result: " + result);
    }
}
